/*
 *    Dynamic table 
 *	  Allows users to interact with the table in many ways
 *
 *    Copyright (C) 2011  Andre Ankru
 *
 *    This file is part of Dynamic table.
 *
 *    Dynamic table is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    Dynamic table is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with Dynamic table.  If not, see <http://www.gnu.org/licenses/>.
 *
 *    For more information or bug fixes email me at collectora@hot.ee
 *
 */
$(function(){
	
	/* Prepare the table cells so we can add dynamic behaviour to them */
	$('#dynTable td').prepareTableCells();
	
	/* Add the dropdown to table cells*/
	$('#dynTable td').TableCellDropdown();
	
	/* Removes the cell dropdown before performing another task (draggable columns don't work properly, if
	dropdown is present in the table cell */
	$(document).click(function(e) {
        $('#dropInnerWrapper').remove();
		return false;
    });
		
	/* If hovering above header cells remove the cell dropdown */
	$('th[scope=row], th[scope=col]').hover(function(){
		$('#dropInnerWrapper').remove();
	});
	
	/* Make the "Add table row" button a jQuery UI button */
	$('#rowButton').hover(function(){
		$('#dropInnerWrapper').remove();
	}).AddTableRow().button({icons: {
                primary: "ui-icon-circle-plus"
    }});
	
	/* Make the "Delete table row button" a jQuery UI button */
	$('#deleteRowButton').DeleteTableRow().button({icons: {
                primary: "ui-icon-circle-minus"
    }});
	
	/* Make the "Add column button" a jQuery UI button and if clicked expand the table area */
	$('#columnButton').hover(function(){
		$('#dropInnerWrapper').remove();
	}).AddTableColumn().button({icons: {
                primary: "ui-icon-circle-plus"
    }}).click(function(){
		$(".tableArea").css({
      		width: function(index, value) {
				var width = $("#dynTable td").outerWidth();
        		return parseFloat(value) + parseFloat(width);
      	}});
	});
	
	/* Make the "Delete column button" a jQuery UI button and if clicked reduce the table area */
	$('#deleteColumnButton').click(function(){
		if($("#dynTable tr:first").find("th").length > 4){
		$(".tableArea").css({
      		width: function(index, value) {
				var width = $("#dynTable td").outerWidth();
        		return parseFloat(value) - parseFloat(width);
      	}})};
	}).DeleteTableColumn().button({icons: {
                primary: "ui-icon-circle-minus"
    }});
	
	/* Show the "Help" portion of the page, also make the "Help" button a jQuery UI button */
	$('#helpButton').click(function(){
		$('#help').fadeIn(1600);
	}).button({icons: {
                primary: "ui-icon-help"
    }});
	
	/* Hide the "Help" portion of the page */
	$('#help .close').click(function(){
		$('#help').fadeOut(1600);
	});
	
	/* Return a helper with preserved width of cells */
	var fixHelper = function(e, ui) {
			ui.children().each(function() {
			$(this).width($(this).width());
		});
	return ui;
	};

	/* Make rows (besides the table header) sortable (jQuery UI) */
	$('#dynTable tbody').sortable({
		helper: fixHelper,
		forcePlaceholderSize: true,
		items: 'tr:not(.header)',
		axis: 'y',
		cursor: 'move',
		containment: 'parent',
		tolerance: 'pointer',
		handle: 'th[scope=row] .handle'
	}).disableSelection();
	
	/* Make table columns sortable (dragtable plugin) */
	$('#dynTable').dragtable({revert:false, dragaccept:'.dragaccept', dragHandle:'.colHandle'});
	
	/* Make cells editable */
	var t = $('#dynTable');
	var options = {};
	$.uiTableEdit( t , options );
	
	/* Human-based computation */
	$('#comp').Computation();
	$('#compUpdate').button( {icons: {
                primary: "ui-icon-refresh"
	}});
});
