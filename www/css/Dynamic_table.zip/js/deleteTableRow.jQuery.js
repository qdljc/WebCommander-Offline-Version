/*
 *    Dynamic table 
 *	  Allows users to interact with the table in many ways
 *
 *    Copyright (C) 2011  Andre Ankru
 *
 *    This file is part of Dynamic table.
 *
 *    Dynamic table is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    Dynamic table is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with Dynamic table.  If not, see <http://www.gnu.org/licenses/>.
 *
 *    For more information or bug fixes email me at collectora@hot.ee
 *
 */
(function($)
{
    $.fn.DeleteTableRow = function()
    {
        return this.each(function()
        {
			var $deleteRowButton = $('#deleteRowButton'),
				$table = $('#dynTable');
				
				$deleteRowButton.click( function (){
					var $last = $table.find('tr:last'),
						len = $table.find('tr').length;
						
					if(len > 4){
						$last.remove();
					} else {
						$('#message').load(
						'messages.html #minRows', function () {
							$('#message').dialog({ title: 'Error'});
						})
					}
					return false;
				});
        });
    };
})(jQuery);
