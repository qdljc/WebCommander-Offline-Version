/*
 *    Dynamic table 
 *	  Allows users to interact with the table in many ways
 *
 *    Copyright (C) 2011  Andre Ankru
 *
 *    This file is part of Dynamic table.
 *
 *    Dynamic table is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    Dynamic table is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with Dynamic table.  If not, see <http://www.gnu.org/licenses/>.
 *
 *    For more information or bug fixes email me at collectora@hot.ee
 *
 */
(function($)
{
    $.fn.TableCellDropdown = function()
    {
		return this.each(function(){
			
			var trigger = $(this).find('.trigger'),
				dropDown =  $(this).find('.dropDown'),
				contents = dropDown.find('#dropInnerWrapper');
			
			trigger.click(function(){
				
				var innerWrapper = $(this).parent(),
					dropDownWrapper =  innerWrapper.find('.dropDown');
				
				dropDownWrapper.load('dropdown.html', function(){
					
					var dropDown = $(this),
						contents = dropDown.find('#dropInnerWrapper'),
						close = dropDown.find('#close'),
						reset = dropDown.find('#reset'),
						bgRed = dropDown.find('#bg-red'),
						bgBlue = dropDown.find('#bg-blue'),
						bgGreen = dropDown.find('#bg-green'),
						bgYellow = dropDown.find('#bg-yellow'),
						txtRed = dropDown.find('#txt-red'),
						txtBlue = dropDown.find('#txt-blue'),
						txtGreen = dropDown.find('#txt-green'),
						txtYellow = dropDown.find('#txt-yellow'),
						color = innerWrapper.css('background-color'),
						txtColor = innerWrapper.css('color'),
						ua = $.browser;

						checkBgColor('rgb(255, 89, 89)', bgRed);
						checkBgColor('rgb(102, 204, 255)', bgBlue);
						checkBgColor('rgb(102, 255, 102)', bgGreen);
						checkBgColor('rgb(255, 255, 102)', bgYellow);
						checkTxtColor('rgb(153, 0, 0)', txtRed);
						checkTxtColor('rgb(0, 0, 102)', txtBlue);
						checkTxtColor('rgb(51, 102, 0)', txtGreen);
						checkTxtColor('rgb(255, 204, 0)', txtYellow);
						
						if (ua.opera || ua.msie && parseInt($.browser.version, 10) == 8 || parseInt($.browser.version, 10) == 7) {
    						checkBgColor('#ff5959', bgRed);
							checkBgColor('#66ccff', bgBlue);
							checkBgColor('#66ff66', bgGreen);
							checkBgColor('#ffff66', bgYellow);
							checkTxtColor('#990000', txtRed);
							checkTxtColor('#000066', txtBlue);
							checkTxtColor('#336600', txtGreen);
							checkTxtColor('#ffcc00', txtYellow);
  						}
						
						setBg(bgRed,'#FF5959');
						setBg(bgBlue,'#66CCFF');
						setBg(bgGreen,'#66FF66');
						setBg(bgYellow,'#FFFF66');
						
						setTxt(txtRed,'#990000');
						setTxt(txtBlue,'#000066');
						setTxt(txtGreen,'#336600');
						setTxt(txtYellow,'#FFCC00');
						
						//Close btn
						close.bind('click', function(){
							contents.remove();
						});
						
						//Reset button
						reset.click(function(){
							innerWrapper.css({
								'color' :	'',
								'background-color' : ''
							});
							innerWrapper.find('.check').css('visibility','hidden');//LISA
							return false; //LISA
						});
						
						function checkBgColor(rgbColor,button){
							if (color == rgbColor){
								button.find('.check').css('visibility','visible');
							}
						}
						
						function checkTxtColor(rgbColor,button){
							if (txtColor == rgbColor){
								button.find('.check').css('visibility','visible');
							}
						}
						
						function setBg(button, color){
							button.click(function (){
								innerWrapper.css('background-color',color);
							});
						}
						
						function setTxt(button, color){
							button.click(function (){
								innerWrapper.css('color',color);
							});
						}
				});
				var ua = $.browser;
  					if ( ua.msie && parseInt($.browser.version, 10) == 8 || parseInt($.browser.version, 10) == 7) {
    					return false;
  					}	
			});	
		});
	};
})(jQuery);