/*
 *    Dynamic table 
 *	  Allows users to interact with the table in many ways
 *
 *    Copyright (C) 2011  Andre Ankru
 *
 *    This file is part of Dynamic table.
 *
 *    Dynamic table is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    Dynamic table is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with Dynamic table.  If not, see <http://www.gnu.org/licenses/>.
 *
 *    For more information or bug fixes email me at collectora@hot.ee
 *
 */
(function($)
{
	$.fn.prepareTableCells = function() {
	    var $el;
	    return this.each(function() {
	        $el = $(this);
	        var newDiv = $("<div />", {
	                "class": "innerWrapper",
	                "css"  : {
	                        "height"  : $el.height(),
	                        "width"   : "100%",
	                        "position": "relative"
	                }
	        });
			var triggerSpan = $("<span />", { "class" : "trigger" });
			var cellInput = $("<div />", { "class" : "cellInput",
											"css" : {
													"height" : $el.height(),
													"width" : $el.width(),
													"display": "block"
													}
												});
			var dropDownWrapper = $("<div />", { "class" : "dropDown" });
			$el.wrapInner(triggerSpan);
			$el.prepend(cellInput);
			$el.prepend(dropDownWrapper);
			$el.wrapInner(newDiv);
	    });
	};
})(jQuery);