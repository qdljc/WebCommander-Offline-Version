/*
 *    Dynamic table 
 *	  Allows users to interact with the table in many ways
 *
 *    Copyright (C) 2011  Andre Ankru
 *
 *    This file is part of Dynamic table.
 *
 *    Dynamic table is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    Dynamic table is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with Dynamic table.  If not, see <http://www.gnu.org/licenses/>.
 *
 *    For more information or bug fixes email me at collectora@hot.ee
 *
 */
(function($)
{
    $.fn.Computation = function()
    {
        return this.each(function()
        {
			var $el = $(this),
				rowsSpan = $el.find('#numRows'),
				colsSpan = $el.find('#numCols'),
				cellsSpan = $el.find('#numCells'),
				coloredSpan = $el.find('#coloredCells'),
				textSpan = $el.find('#textCells'),
				redsSpan = $el.find('#redsPercent'),
				bluesSpan = $el.find('#bluesPercent'),
				greensSpan = $el.find('#greensPercent'),
				yellowsSpan = $el.find('#yellowsPercent'),
				updateBtn = $el.find('#compUpdate');
				
			var dynTable = $('#dynTable'),
				rows = dynTable.find('tr').length,
				cols = dynTable.find('tr:first th').length;
				
				cells = (rows - 1)*(cols - 1);
				
				//Initial tabel stats
				rowsSpan.html(rows);
				colsSpan.html(cols);
				cellsSpan.html(cells);
				coloredSpan.html('0');
				textSpan.html('0');
				redsSpan.prepend('0');
				bluesSpan.prepend('0');
				greensSpan.prepend('0');
				yellowsSpan.prepend('0');
			
				//UPDATE tabel stats
				updateBtn.click(function (){
					rows = dynTable.find('tr').length;
					cols = dynTable.find('tr:first th').length;
					cells = dynTable.find('td');
					reds = $();
					blues = $();
					greens = $();
					yellows = $();
					colored = 0;
					text = 0;
					ua = $.browser;
					
					rowsSpan.html(rows);
					colsSpan.html(cols);
					cellsSpan.html(cells.length);
					
					cells.each(function(){
						if($(this).find('.innerWrapper').css('background-color') != 'transparent'){
							colored++;
							
							//Colored cell pos %
							if($(this).find('.innerWrapper').css('background-color') == 'rgb(255, 89, 89)'){
								reds = reds.add(this);
							}
							if($(this).find('.innerWrapper').css('background-color') == 'rgb(102, 204, 255)'){
								blues = blues.add(this);
							}
							if($(this).find('.innerWrapper').css('background-color') == 'rgb(102, 255, 102)'){
								greens = greens.add(this);
							}
							if($(this).find('.innerWrapper').css('background-color') == 'rgb(255, 255, 102)'){
								yellows = yellows.add(this);
							}
							
							if (ua.opera || ua.msie && parseInt($.browser.version, 10) == 8 || parseInt($.browser.version, 10) == 7) {
								if($(this).find('.innerWrapper').css('background-color') == '#ff5959'){
									reds = reds.add(this);
								}
								if($(this).find('.innerWrapper').css('background-color') == '#66ccff'){
									blues = blues.add(this);
								}
								if($(this).find('.innerWrapper').css('background-color') == '#66ff66'){
									greens = greens.add(this);
								}
								if($(this).find('.innerWrapper').css('background-color') == '#ffff66'){
									yellows = yellows.add(this);
								}
  							}
						}
					});
					
					coloredSpan.html(colored);
					
					function calcColorConnections(color){
						//Variables
						maxPositionPercent = 0;
						successfulPos = 0;
						maxSuccessfulPos = 0;
						
						//Calculate succesful connections
						for(i = 0 ; i <= color.length - 1 ; i++){
								
							previousElem = $(color[i]).prev(); 				//previous cell to the matched element
							nextElem = $(color[i]).next();     				//next cell to the matched element
							elemNextParent = $(color[i]).parent().next();	//elements next parent
							elemPrevParent = $(color[i]).parent().prev();	//elements previous parent
	
							for(j = 0 ; j <= color.length - 1 ; j++){
								if($(color[j]).get(0) == $(previousElem).get(0) || $(color[j]).get(0) == $(nextElem).get(0)){
									successfulPos++;
								}
								if($(color[j]).parent().get(0) == $(elemPrevParent).get(0) || $(color[j]).parent().get(0) == $(elemNextParent).get(0)){
									if($(color[j]).index() == $(color[i]).index()){
										successfulPos++;
									}
								}
							}
						}
						
						if(color.length == 1){
							maxSuccessfulPos = 0;
						}
						
						if(color.length == 2){
							maxSuccessfulPos = 2;
						}
					
						if(color.length > 2){
							//Calculate maximum successful positionings
							maxSuccessfulPos = 2;
							elem = color.length;
							function g(x) {
								return Math.round((Math.round(((x+1)/2)))+1);
							}
							function f(x) {
								return x > 0 ? f(x-1)+g(x-1) : 1;
							}
							var compArray = new Array();
	
							for (i = 0; i < elem - 2; i++) {
								compArray[i] = f(i);
							}
							
							// FIX for IE 8 and below (doesn't support Array.indexOf)
							if(!Array.indexOf){
	    						Array.prototype.indexOf = function(obj){
	        						for(var i=0; i<this.length; i++){
	            						if(this[i]==obj){
	                						return i;
	            						}
	        						}
	        						return -1;
	    						}
							}
							
							for(i = 1 ; i <= elem - 2 ; i++){
								if( compArray.indexOf(i) == -1){
									maxSuccessfulPos += 4;
								}else{
									maxSuccessfulPos += 2;
								}
							}
						}
						
						maxPositionPercent = successfulPos / maxSuccessfulPos * 100;
						//Round to 2 decimal points
						roundedResult = Math.round(maxPositionPercent*100)/100;
						
						return roundedResult;
					}
					
					//Calculated results for all colors
					redsResult = calcColorConnections(reds);
					bluesResult = calcColorConnections(blues);
					greensResult = calcColorConnections(greens);
					yellowsResult = calcColorConnections(yellows);

					//Insert stats to span elements					
					redsSpan.html(redsResult + '%');
					bluesSpan.html(bluesResult + '%');
					greensSpan.html(greensResult + '%');
					yellowsSpan.html(yellowsResult + '%');
					
					cells.each(function(){
						if($(this).find('.cellInput').html() != ''){
							text++;
						}
					});
					textSpan.html(text);
					return false;
				});	
        });
    };
})(jQuery);
